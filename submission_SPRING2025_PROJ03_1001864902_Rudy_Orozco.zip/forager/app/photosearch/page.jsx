import BackgroundScreen from '../../components/BackgroundScreen';
import Link from 'next/link';

export default function PhotoSearchPage() {
  return (
    <div className="fixed top-0 left-0 w-screen h-screen z-50">
      <BackgroundScreen />
    </div>
  );
}
